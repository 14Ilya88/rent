<?php
use App\Services\Page;
?>
<html>
<?php
Page::par('head');
?>
<body>
<?php
Page::par('navbar');
?>
<div class="container-xxl">
    <h1>404 n0t found</h1>
</div>
</body>
</html>


